package edu.cvtc.enoughnewproject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "testServlet", value = "/test")
public class testServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");

        PrintWriter ourWriter = response.getWriter();
        ourWriter.println("<html>");
        ourWriter.println("<body>");
        ourWriter.println("<head><title>Get Response Page</title></head>");
        ourWriter.println("<body>");
        ourWriter.println("<h1>Welcome Traveler!</h1>");
        ourWriter.println("<p>You made a request, i supply your request</p>");
        ourWriter.println("<body>");
        ourWriter.println("<html>");

        ourWriter.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
